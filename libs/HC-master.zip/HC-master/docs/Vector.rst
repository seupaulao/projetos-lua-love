HC.vector
=========

::

  vector = require 'HC.vector'

See ``hump.vector_light``.
